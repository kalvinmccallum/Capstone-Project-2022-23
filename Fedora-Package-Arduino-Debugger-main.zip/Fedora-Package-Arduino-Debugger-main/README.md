# Fedora-Package-Arduino-Debugger
The following repository captures the spec file and rpm file needed to package and install an arduino debugger tool into Fedora.
The original software can be found at: https://github.com/kimballa/arduino-dbg
